package com.kafka.action.chapter6.connector;

/**
 * 
* Description: <br/>
* @author moudaen
* @date 2017年4月1日
* @version 1.0
 */
public class FileSourceConnector {

	public static void main(String[] args) {
		System.out.println("ksks");
	}
}
