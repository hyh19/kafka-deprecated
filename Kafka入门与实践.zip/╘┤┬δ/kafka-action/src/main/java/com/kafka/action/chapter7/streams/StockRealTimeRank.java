package com.kafka.action.chapter7.streams;



public class StockRealTimeRank {

	public static void rank() {}
	public static void main(String[] args) {
		rank();
	}
}
